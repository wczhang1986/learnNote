self.addEventListener('push', function (event) {
  let data = event.data.json();
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      // icon: data.icon,
      // badge: data.badge
    })
  );
});
self.addEventListener('notificationclick', function (event) {
  event.notification.close();
});