const express = require('express')  //导入express，需要下载
const fs = require('fs')

const app = express()
app.use('/static', express.static('public'))  // 静态资源托管

app.get('/', (req, res) => {  // 开启一个路由  /  
  fs.readFile('test.html', function (err, data) {
      if (err) {
          throw err
      } else {
          // res.send('Hello World!')
          res.end(data)
      }
  })
})
app.listen(3000, () => {
  console.log('服务器已经启动,请访问 http://localhost:3000')
})
